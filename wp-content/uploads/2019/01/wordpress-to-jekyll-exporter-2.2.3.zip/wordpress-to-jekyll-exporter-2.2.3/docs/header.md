=== Jekyll Exporter ===
Contributors: benbalter
Tags: jekyll, github, github pages, yaml, export
Requires at least: 4.4
Tested up to: 4.6.0
Stable tag: 2.2.3
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html
